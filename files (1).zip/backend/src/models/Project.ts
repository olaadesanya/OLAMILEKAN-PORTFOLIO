import { Schema, model } from "mongoose";

const TaskSchema = new Schema({
  title: String,
  description: String,
  assignedTo: { type: Schema.Types.ObjectId, ref: "User" },
  dueDate: Date,
  status: { type: String, enum: ["Pending", "In Progress", "Completed"], default: "Pending" },
  completedAt: Date,
  jitsiRoom: String,
});

const ProjectSchema = new Schema({
  name: String,
  description: String,
  startDate: Date,
  endDate: Date,
  tasks: [TaskSchema],
  team: [{ type: Schema.Types.ObjectId, ref: "User" }],
  createdBy: { type: Schema.Types.ObjectId, ref: "User" },
});

export default model("Project", ProjectSchema);