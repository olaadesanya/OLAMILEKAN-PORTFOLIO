import express from "express";
import Project from "../models/Project";
import User from "../models/User";
import { authenticate } from "../utils/authenticate";
const router = express.Router();

// List all projects with populated team and tasks
router.get("/", authenticate, async (req, res) => {
  const projects = await Project.find().populate("team tasks.assignedTo");
  res.json(projects);
});

// Create new project
router.post("/", authenticate, async (req, res) => {
  const project = new Project({ ...req.body, createdBy: req.user.userId });
  await project.save();
  res.status(201).json(project);
});

// Add a task to a project
router.post("/:projectId/task", authenticate, async (req, res) => {
  const { projectId } = req.params;
  const { title, description, assignedTo, dueDate, jitsiRoom } = req.body;
  const project = await Project.findById(projectId);
  if (!project) return res.sendStatus(404);
  project.tasks.push({ title, description, assignedTo, dueDate, jitsiRoom });
  await project.save();
  res.status(201).json(project);
});

// Update task status and notify
router.patch("/:projectId/tasks/:taskId/status", authenticate, async (req, res) => {
  const { projectId, taskId } = req.params;
  const { status } = req.body;
  const project = await Project.findById(projectId);
  if (!project) return res.sendStatus(404);
  const task = project.tasks.id(taskId);
  if (!task) return res.sendStatus(404);
  task.status = status;
  if (status === "Completed") task.completedAt = new Date();
  await project.save();
  req.app.get("io").emit("taskStatusUpdate", { projectId, taskId, status });
  res.json(task);
});

export default router;