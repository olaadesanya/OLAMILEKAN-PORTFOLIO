import express from "express";
import http from "http";
import cors from "cors";
import mongoose from "mongoose";
import { Server } from "socket.io";
import authRoutes from "./routes/auth";
import projectRoutes from "./routes/project";

const app = express();
app.use(cors());
app.use(express.json());

mongoose.connect("mongodb://localhost:27017/powertrim_tracker", {});

const server = http.createServer(app);
const io = new Server(server, { cors: { origin: "*" } });
app.set("io", io);

io.on("connection", (socket) => {
  console.log("User connected:", socket.id);
});

app.use("/api/auth", authRoutes);
app.use("/api/projects", projectRoutes);

server.listen(5000, () => console.log("Backend on http://localhost:5000"));