import React, { useState } from "react";
import { Box, Accordion, AccordionSummary, AccordionDetails, Typography, Chip, Button, Grid, Dialog } from "@mui/material";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import TaskAltIcon from "@mui/icons-material/TaskAlt";
import VideoCallIcon from "@mui/icons-material/VideoCall";
import TaskEditor from "./TaskEditor";

function ProjectList({ projects, setRefresh, socket, user }) {
  const [openTaskEditor, setOpenTaskEditor] = useState(false);
  const [currentProject, setCurrentProject] = useState(null);

  return (
    <Box>
      <Button
        variant="contained"
        sx={{ mb: 2 }}
        onClick={() => { setOpenTaskEditor(true); setCurrentProject(projects[0] || null); }}
        disabled={user.role === "Field Worker"}
      >
        Add Task to First Project
      </Button>
      <Dialog open={openTaskEditor} onClose={() => setOpenTaskEditor(false)} maxWidth="sm" fullWidth>
        <TaskEditor 
          project={currentProject} 
          onClose={() => { setOpenTaskEditor(false); setRefresh(r => r+1); }} 
        />
      </Dialog>
      {projects.map(project => (
        <Accordion key={project._id} sx={{ mb: 2 }}>
          <AccordionSummary expandIcon={<ExpandMoreIcon />}>
            <Typography variant="h6">{project.name}</Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Typography>{project.description}</Typography>
            <Grid container spacing={1} mt={2}>
              {project.tasks.map(task => (
                <Grid item xs={12} sm={6} md={4} key={task._id}>
                  <Box p={2} borderRadius={2} bgcolor="#f8fafc" boxShadow={1} mb={1}>
                    <Typography fontWeight="bold">{task.title}</Typography>
                    <Typography fontSize={13}>{task.description}</Typography>
                    <Chip
                      label={task.status}
                      color={
                        task.status === "Completed"
                          ? "success"
                          : task.status === "In Progress"
                          ? "warning"
                          : "default"
                      }
                      icon={task.status === "Completed" ? <TaskAltIcon /> : null}
                      size="small"
                      sx={{ mt: 1, mr: 1 }}
                    />
                    {task.jitsiRoom && (
                      <Button
                        size="small"
                        startIcon={<VideoCallIcon />}
                        color="info"
                        sx={{ mt: 1, ml: 1 }}
                        href={`https://meet.jit.si/${task.jitsiRoom}`}
                        target="_blank"
                      >
                        Join Meeting
                      </Button>
                    )}
                  </Box>
                </Grid>
              ))}
            </Grid>
          </AccordionDetails>
        </Accordion>
      ))}
    </Box>
  );
}
export default ProjectList;