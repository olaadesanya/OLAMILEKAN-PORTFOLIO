import React, { useState } from "react";
import { DialogTitle, DialogContent, DialogActions, TextField, Button } from "@mui/material";

function TaskEditor({ project, onClose }) {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [jitsiRoom, setJitsiRoom] = useState("");
  const [dueDate, setDueDate] = useState("");

  const handleAdd = async () => {
    await fetch(`http://localhost:5000/api/projects/${project._id}/task`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${localStorage.getItem("token")}` },
      body: JSON.stringify({ title, description, dueDate, jitsiRoom })
    });
    onClose();
  };

  return (
    <>
      <DialogTitle>Add Task to {project?.name}</DialogTitle>
      <DialogContent>
        <TextField label="Title" value={title} onChange={e => setTitle(e.target.value)} fullWidth margin="normal" />
        <TextField label="Description" value={description} onChange={e => setDescription(e.target.value)} fullWidth margin="normal" />
        <TextField label="Due Date" type="date" value={dueDate} onChange={e => setDueDate(e.target.value)} fullWidth margin="normal" InputLabelProps={{ shrink: true }} />
        <TextField label="Jitsi Room Name" value={jitsiRoom} onChange={e => setJitsiRoom(e.target.value)} fullWidth margin="normal" helperText="Optional: for video meeting" />
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>Cancel</Button>
        <Button variant="contained" onClick={handleAdd}>Add Task</Button>
      </DialogActions>
    </>
  );
}
export default TaskEditor;