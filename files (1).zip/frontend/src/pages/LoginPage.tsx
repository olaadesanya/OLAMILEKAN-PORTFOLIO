import React, { useState } from "react";
import { Box, Button, Card, CardContent, TextField, Typography, CircularProgress } from "@mui/material";

function LoginPage({ setUser }) {
  const [email, setEmail] = useState("admin@powertrim.com");
  const [password, setPassword] = useState("adminpass");
  const [loading, setLoading] = useState(false);

  const login = async (e) => {
    e.preventDefault();
    setLoading(true);
    const res = await fetch("http://localhost:5000/api/auth/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password })
    });
    const data = await res.json();
    setLoading(false);
    if (data.token) {
      setUser(data.user);
      localStorage.setItem("token", data.token);
    } else {
      alert("Login failed");
    }
  };
  return (
    <Box minHeight="100vh" display="flex" justifyContent="center" alignItems="center" bgcolor="#f2f6fb">
      <Card sx={{ minWidth: 340, p: 3 }}>
        <CardContent>
          <Typography variant="h5" align="center" color="primary" gutterBottom>
            POWERTRIM NIGERIA LIMITED PROJECT TRACKERS
          </Typography>
          <form onSubmit={login}>
            <TextField label="Email" value={email} onChange={e => setEmail(e.target.value)}
              fullWidth margin="normal" />
            <TextField label="Password" type="password" value={password}
              onChange={e => setPassword(e.target.value)}
              fullWidth margin="normal" />
            <Button
              type="submit"
              variant="contained"
              color="primary"
              fullWidth
              sx={{ mt: 2 }}
              disabled={loading}
              endIcon={loading && <CircularProgress size={16} />}
            >
              Login
            </Button>
          </form>
        </CardContent>
      </Card>
    </Box>
  );
}

export default LoginPage;