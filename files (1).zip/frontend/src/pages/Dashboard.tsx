import React, { useEffect, useState } from "react";
import { Box, AppBar, Toolbar, Typography, Button, Grid, Paper, IconButton } from "@mui/material";
import LogoutIcon from "@mui/icons-material/Logout";
import ProjectList from "../components/ProjectList";
import KPICard from "../components/KPICard";

function Dashboard({ user, socket }) {
  const [projects, setProjects] = useState([]);
  const [refresh, setRefresh] = useState(0);

  useEffect(() => {
    fetch("http://localhost:5000/api/projects", {
      headers: { Authorization: `Bearer ${localStorage.getItem("token")}` }
    })
    .then(res => res.json())
    .then(setProjects);
  }, [refresh]);

  // KPI calculations
  const totalProjects = projects.length;
  const totalTasks = projects.reduce((acc, p) => acc + p.tasks.length, 0);
  const completed = projects.reduce((acc, p) => acc + p.tasks.filter(t => t.status === "Completed").length, 0);
  const inProgress = projects.reduce((acc, p) => acc + p.tasks.filter(t => t.status === "In Progress").length, 0);
  const pending = projects.reduce((acc, p) => acc + p.tasks.filter(t => t.status === "Pending").length, 0);

  return (
    <Box sx={{ flexGrow: 1, bgcolor: "#f2f6fb", minHeight: "100vh" }}>
      <AppBar position="static" color="primary">
        <Toolbar>
          <Typography variant="h6" sx={{ flexGrow: 1 }}>
            POWERTRIM NIGERIA LTD PROJECT TRACKERS
          </Typography>
          <Typography variant="body2" sx={{ mr: 2 }}>{user?.name} ({user?.role})</Typography>
          <IconButton color="inherit" onClick={() => {localStorage.clear(); window.location.reload();}}>
            <LogoutIcon />
          </IconButton>
        </Toolbar>
      </AppBar>
      <Box p={2}>
        <Grid container spacing={2}>
          <Grid item xs={12} sm={3}><KPICard title="Projects" value={totalProjects} color="primary" /></Grid>
          <Grid item xs={12} sm={3}><KPICard title="Total Tasks" value={totalTasks} color="info" /></Grid>
          <Grid item xs={12} sm={2}><KPICard title="Completed" value={completed} color="success" /></Grid>
          <Grid item xs={12} sm={2}><KPICard title="In Progress" value={inProgress} color="warning" /></Grid>
          <Grid item xs={12} sm={2}><KPICard title="Pending" value={pending} color="error" /></Grid>
        </Grid>
        <Box mt={4}>
          <ProjectList projects={projects} setRefresh={setRefresh} socket={socket} user={user} />
        </Box>
      </Box>
    </Box>
  );
}
export default Dashboard;