import React, { useEffect, useState } from "react";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { CssBaseline, Snackbar, Alert } from "@mui/material";
import io from "socket.io-client";
import LoginPage from "./pages/LoginPage";
import Dashboard from "./pages/Dashboard";

const socket = io("http://localhost:5000");

function App() {
  const [user, setUser] = useState(null);
  const [notification, setNotification] = useState("");

  useEffect(() => {
    socket.on("taskStatusUpdate", (data) => {
      setNotification(`Task status updated: ${data.status}`);
    });
    return () => { socket.off("taskStatusUpdate"); };
  }, []);

  return (
    <BrowserRouter>
      <CssBaseline />
      <Snackbar open={!!notification} autoHideDuration={4000} onClose={() => setNotification("")}>
        <Alert severity="info">{notification}</Alert>
      </Snackbar>
      <Routes>
        <Route path="/login" element={<LoginPage setUser={setUser}/>} />
        <Route path="/dashboard" element={user ? <Dashboard user={user} socket={socket}/> : <Navigate to="/login" />} />
        <Route path="*" element={<Navigate to={user ? "/dashboard" : "/login"} />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;