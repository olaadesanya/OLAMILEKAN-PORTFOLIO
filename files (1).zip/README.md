# POWERTRIM NIGERIA LIMITED PROJECT TRACKERS

A modern, responsive, real-time web app for oilfield maintenance scheduling, progress tracking, and reporting, featuring video conferencing.

## Features

- Project and Task management
- Real-time notifications
- User Authentication (Admin, Supervisor, Field Worker)
- Responsive Material UI dashboard with KPIs
- Jitsi Meet integration for video calls
- Calendar-style task scheduling
- Reporting

## Quickstart

1. **Backend**
   - `cd backend`
   - `npm install`
   - `npm run start`

2. **Frontend**
   - `cd frontend`
   - `npm install`
   - `npm start`

3. Open [http://localhost:3000](http://localhost:3000) to view the app.

## Demo Login

- Email: `admin@powertrim.com`
- Password: `adminpass`

---

MIT License